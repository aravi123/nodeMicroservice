/**
 * Created by aravind on 20/9/17.
 */
const thumbnail = require('node-thumbnail').thumb;
const imagedownloader = require('image-downloader');

let generatethumbnail = (img)=>{

	const options = {
		url:img,
		dest:'./images'
	};
	return new Promise((resolve,reject)=> {
		imagedownloader.image(options).then(({filename, image}) => {
			console.log(filename);
			thumbnail({
				source: filename,
				destination: 'thumbnail',
			}, (files, err, stdout, stderr) => {
				console.log(files);
				resolve(files[0].dstPath);
			})
		}).catch((err) => {
			console.log(err);
			reject("error");
		});
	}).then((filename)=>{
		console.log(filename);
		return filename;
	}).catch((err)=>{
		return err;
	})


};

module.exports = {generatethumbnail:generatethumbnail};